"""
ASKE - Platform Architect Development Framework
"""

__version__ = "0.2.0"

from .core import Platform

__all__ = ["Platform"]
