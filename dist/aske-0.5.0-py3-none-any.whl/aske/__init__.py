"""
ASKE - Platform Architect Development Framework
"""

__version__ = "0.5.0"

from .core import Platform

__all__ = ["Platform"]
